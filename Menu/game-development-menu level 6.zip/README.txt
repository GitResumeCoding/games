A Pen created at CodePen.io. You can find this one at http://codepen.io/chihealthdev/pen/GrrvjL.

 Originally when I first made this I just wanted to make an animated accordion with mostly CSS and some simple javascript. I've since added Aria roles and fixed up that Javascript to work better.